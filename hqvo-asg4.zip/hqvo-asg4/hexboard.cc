//assignment 4
//displaying the hex board
//to do a node struct was created to track neighbors and 
//overloading was perform to present the board

#include <iostream>
#include <vector>
#include <cstdlib>
#include <random>
#include <chrono> 
#include <algorithm>
#include <set>
#include <utility>

using namespace std;

//make a random seed for the shuffle in the movement function
double seed (int i) { return rand()%i;}

typedef int vertex_n;

//the 2 colors used for the game 
enum colors_t {black, white, empty};

//the struct for each of the hex squares
struct node 
{
   vertex_n x;
   vertex_n y;
   colors_t color = empty;
   //pointers to the neighbor hexs
   vector<node*> surroundNode;
   bool visited = false;
};

//class for the hexboard
class graph
{
public:
   //this is work for the next part nothing to see here
   vector<pair<int,int>> blackpathway, whitepathway;
   
   //the constructor
   graph(int s = 6){
      //set size to the s input
      size = s;
      g1.resize(size);
      //cycle through the graph and initializes
      for(auto i = 0; i < size; i++)
      {
         g1[i].resize(size);
         for(auto j = 0; j < size; j++)
         {
            //sets the x and y position
            g1[i][j].x = i;
            g1[i][j].y = j;

            //also stores list of all position to use in shuffle 
            //in the movement function
            position.push_back(make_pair(i,j));
         }
      }
      //assigns the pointers to the neighboring nodes
      for(auto i = 0; i < size; i++)
      {
         for(auto j = 0; j < size; j++)
         {

            neighborNodes(&g1[i][j], 0, -1);
            neighborNodes(&g1[i][j], 1, -1);
            neighborNodes(&g1[i][j], -1, 0);
            neighborNodes(&g1[i][j], 1, 0);
            neighborNodes(&g1[i][j], -1, 1);
            neighborNodes(&g1[i][j], 0, 1);
         }
      }
   }

   //overloading the << 
   friend ostream& operator<<(ostream& os, const graph& dt);

   //assigning the neighbors to the nodes
   void neighborNodes (node *temp, int i, int j)
   {
      int tempI = temp->x + i;
      int tempJ = temp->y + j;
      if(tempI < 0 || tempI >= size || tempJ < 0 || tempJ >= size)
      {
         return;
      }
      temp->surroundNode.push_back(&g1[tempI][tempJ]);
   }

   //the movement for the game
   void movement()
   {
      //gets the number of nodes there are 11*11=121 nodes
      int numberNode = size*size;
      //randomly shuffle all of the positions (initialize in the constructor)
      random_shuffle(position.begin(), position.end(), seed);
      //how I keep track whos turn it is
      int count = 1;
      //goes through all of the position 
      while(!position.empty())
      {
         int i = position.back().first;
         int j = position.back().second;
         position.pop_back();
         //even is blacks turn and it will get a shuffle position and make it black
         if(count%2 == 0)
         {
            g1[i][j].color = black;
            blackpathway.push_back(make_pair(i,j));
         }
         else
         {
            g1[i][j].color = white;
            whitepathway.push_back(make_pair(i,j));
         }
         count++; 

      }
      
   }
   //search for a winner 
   string searchForWinner()
   {
      for(int i = 0; i<size; i++)
      {
         if(g1[i][0].color == white)
         {
            //making a queue
            set<pair<vertex_n, vertex_n>> vQueue;
            vQueue.insert(make_pair(i, 0));
            //assigned the visited node to true
            g1[i][0].visited = true;
            vertex_n tempX;
            vertex_n tempY;
            while(!vQueue.empty())
            {
               tempX=vQueue.begin()->first;
               tempY=vQueue.begin()->second;
               vQueue.erase(vQueue.begin());
               //return the winner is the end is reach 
               //else the other one is the winner
               if(tempY == size-1){
                  return "White";
               }
               //checks the neighbor
               for(auto i : g1[tempX][tempY].surroundNode)
               {
                  if(!i->visited && i->color == white)
                  {
                     i->visited = true;
                     vQueue.insert(make_pair(i->x, i->y));
                  }
               }
            }
         }
      }
      //for a 11x11 there is no tie so is white did not win then
      //black has won
      return "Black";
   }
private:
   int size;
   //the hex board
   vector<vector<node>> g1;
   vector<pair<int,int>> position;
};

//overloading the <<
ostream& operator<<(ostream& os, const graph& printG)
{
   os << "RESULT OF HEX BOARD" << endl;
   for(auto i = 0; i < printG.size; i++)
   {
      //make it look like a rombus for hexboard
      os << string(i, ' ');
      for(auto j = 0; j < printG.size; j++)
      {

         if(printG.g1[i][j].color == white)
            os << "O ";
         else if(printG.g1[i][j].color == black)
            os << "X "; 
      }
      os << endl;
   }  

} 

//main function
int main()
{
   srand(time(0));
   graph test1(11);
   test1.movement();
   cout << test1;
   cout << "the winner is : " << test1.searchForWinner() << endl;
}